require('dotenv').config();

const fs = require('fs');
const path = require('path');
const mongoose = require('mongoose');
const User = require('./models/User');
const Item = require('./models/Item');

const daysAgo = (days) => new Date(Date.now() - days * 24 * 60 * 60 * 1000);

const seedImagesDir = path.join(__dirname, 'seed-images');
const uploadsDir = path.join(__dirname, 'public', 'uploads');

// Copies a photo from seed-images/ into public/uploads/ and returns the URL to store on the item.
// The originals stay in seed-images/, so deleting an item in the admin panel (which removes its
// file from public/uploads/) never loses the photo, and re-running the seed restores it.
const seedImage = (fileName) => {
  const source = path.join(seedImagesDir, fileName);

  if (!fs.existsSync(source)) {
    console.warn(`Missing seed image: seed-images/${fileName} (item will have no photo)`);
    return '';
  }

  fs.mkdirSync(uploadsDir, { recursive: true });
  fs.copyFileSync(source, path.join(uploadsDir, `seed-${fileName}`));
  return `/uploads/seed-${fileName}`;
};

const seed = async () => {
  if (!process.env.MONGO_URI) {
    console.error('MONGO_URI is missing in .env file');
    process.exit(1);
  }

  try {
    await mongoose.connect(process.env.MONGO_URI);

    // Warning: this wipes all existing users and items before seeding.
    await User.deleteMany({});
    await Item.deleteMany({});

    const admin = await User.create({
      name: 'Admin',
      email: 'admin@college.edu',
      password: 'password123',
      role: 'admin',
    });

    const student = await User.create({
      name: 'John Doe',
      email: 'student@college.edu',
      password: 'password123',
      role: 'student',
    });

    const priya = await User.create({
      name: 'Priya Patel',
      email: 'priya@college.edu',
      password: 'password123',
      role: 'student',
    });

    const rahul = await User.create({
      name: 'Rahul Shah',
      email: 'rahul@college.edu',
      password: 'password123',
      role: 'student',
    });

    const staff = await User.create({
      name: 'Prof. Mehta',
      email: 'staff@college.edu',
      password: 'password123',
      role: 'staff',
    });

    await Item.create([
      // --- original items ---
      {
        title: 'Teal Water Bottle',
        imageUrl: seedImage('water-bottle.jpg'),
        description: 'Reusable teal steel bottle with a round college crest sticker on the front.',
        category: 'other',
        type: 'lost',
        location: 'Library',
        date: daysAgo(1),
        status: 'pending',
        reportedBy: student._id,
      },
      {
        title: 'Calculus Textbook',
        imageUrl: seedImage('calculus-textbook.jpg'),
        description: 'Found a calculus textbook with notes inside the cover.',
        category: 'documents',
        type: 'found',
        location: 'Room 101',
        date: daysAgo(2),
        status: 'pending',
        reportedBy: student._id,
      },
      {
        title: 'MacBook Charger',
        imageUrl: seedImage('macbook-charger.jpg'),
        description: 'Apple MagSafe charger reported lost near the cafeteria seating area.',
        category: 'electronics',
        type: 'lost',
        location: 'Cafeteria',
        date: daysAgo(12),
        status: 'resolved',
        reportedBy: student._id,
        verifiedBy: admin._id,
      },

      // --- electronics ---
      {
        title: 'Black Wireless Earbuds',
        imageUrl: seedImage('wireless-earbuds.jpg'),
        description: 'Black earbuds in a small charging case with a scratch on the lid. Lost after the evening lab session.',
        category: 'electronics',
        type: 'lost',
        location: 'Computer Lab 2',
        date: daysAgo(3),
        status: 'pending',
        reportedBy: priya._id,
      },
      {
        title: 'Samsung Phone With Cracked Screen',
        imageUrl: seedImage('samsung-phone.jpg'),
        description: 'Found a Samsung Galaxy S6 edge with a badly shattered screen on a bench outside the main gate.',
        category: 'electronics',
        type: 'found',
        location: 'Main Gate',
        date: daysAgo(4),
        status: 'claimed',
        reportedBy: staff._id,
        verifiedBy: admin._id,
      },
      {
        title: 'Casio Scientific Calculator',
        imageUrl: seedImage('calculator.jpg'),
        description: 'Casio fx-991ES Plus scientific calculator with initials "R.S." written on the back. Left on a desk after the mid-sem exam.',
        category: 'electronics',
        type: 'lost',
        location: 'Exam Hall B',
        date: daysAgo(6),
        status: 'resolved',
        reportedBy: rahul._id,
        verifiedBy: admin._id,
      },
      {
        title: 'SanDisk Pen Drive',
        imageUrl: seedImage('pen-drive.jpg'),
        description: 'Black and red SanDisk pen drive found plugged into a projector computer. May contain presentation files.',
        category: 'electronics',
        type: 'found',
        location: 'Seminar Hall',
        date: daysAgo(5),
        status: 'pending',
        reportedBy: staff._id,
      },

      // --- documents ---
      {
        title: 'College ID Card',
        imageUrl: seedImage('college-id-card.jpg'),
        description: 'Blue and white student ID card with a photo and barcode. The name on the card starts with "A".',
        category: 'documents',
        type: 'found',
        location: 'Canteen',
        date: daysAgo(2),
        status: 'pending',
        reportedBy: priya._id,
      },
      {
        title: 'Engineering Mathematics Notebook',
        imageUrl: seedImage('math-notebook.jpg'),
        description: 'Spiral notebook with handwritten notes for unit 3 and 4. Cover shows black cats sitting on a pile of books.',
        category: 'documents',
        type: 'lost',
        location: 'Room 204',
        date: daysAgo(7),
        status: 'pending',
        reportedBy: rahul._id,
      },
      {
        title: 'Brown Folder With Certificates',
        imageUrl: seedImage('brown-folder.jpg'),
        description: 'Brown document folder with mark sheets and two certificates inside. Urgent, needed for a scholarship form.',
        category: 'documents',
        type: 'lost',
        location: 'Admin Office',
        date: daysAgo(1),
        status: 'claimed',
        reportedBy: student._id,
        verifiedBy: admin._id,
      },

      // --- keys ---
      {
        title: 'Bike Keys With Red Keychain',
        imageUrl: seedImage('bike-keys.jpg'),
        description: 'Two keys on a red keychain with a small football charm. Lost somewhere between the parking lot and the library.',
        category: 'keys',
        type: 'lost',
        location: 'Parking Lot',
        date: daysAgo(8),
        status: 'pending',
        reportedBy: rahul._id,
      },
      {
        title: 'Locker Key Number 47',
        imageUrl: seedImage('locker-key-47.jpg'),
        description: 'Small silver key tagged with number 47, found on the floor near the sports lockers.',
        category: 'keys',
        type: 'found',
        location: 'Sports Complex',
        date: daysAgo(3),
        status: 'resolved',
        reportedBy: staff._id,
        verifiedBy: admin._id,
      },

      // --- clothing ---
      {
        title: 'Grey Hoodie',
        imageUrl: seedImage('grey-hoodie.jpg'),
        description: 'Grey zip-up cotton-blend hoodie with a small stain on one sleeve. Left on a chair during the cultural fest.',
        category: 'clothing',
        type: 'lost',
        location: 'Auditorium',
        date: daysAgo(9),
        status: 'pending',
        reportedBy: priya._id,
      },
      {
        title: 'Black Umbrella',
        imageUrl: seedImage('black-umbrella.jpg'),
        description: 'Large black umbrella with a curved wooden handle, found near the entrance after the rain.',
        category: 'clothing',
        type: 'found',
        location: 'Block A Entrance',
        date: daysAgo(10),
        status: 'resolved',
        reportedBy: student._id,
        verifiedBy: admin._id,
      },

      // --- other ---
      {
        title: 'Prescription Glasses',
        imageUrl: seedImage('prescription-glasses.jpg'),
        description: 'Black rectangular frame glasses in a blue hard case. Found on a table in the reading section.',
        category: 'other',
        type: 'found',
        location: 'Library',
        date: daysAgo(2),
        status: 'pending',
        reportedBy: rahul._id,
      },
      {
        title: 'Steel Lunch Box',
        imageUrl: seedImage('lunch-box.jpg'),
        description: 'Green stainless-steel lunch box with three compartments and clip-on lid. Lost after lunch break.',
        category: 'other',
        type: 'lost',
        location: 'Cafeteria',
        date: daysAgo(4),
        status: 'pending',
        reportedBy: priya._id,
      },
      {
        title: 'Badminton Racket',
        imageUrl: seedImage('badminton-racket.jpg'),
        description: 'Yonex racket in a black cover with the name "Neel" on the handle grip.',
        category: 'other',
        type: 'lost',
        location: 'Indoor Court',
        date: daysAgo(5),
        status: 'claimed',
        reportedBy: student._id,
        verifiedBy: admin._id,
      },
    ]);

    console.log('Database seeded successfully (5 users, 17 items with photos).');
    console.log('Admin login:   admin@college.edu / password123');
    console.log('Student login: student@college.edu / password123');
    console.log('Other logins:  priya@college.edu, rahul@college.edu, staff@college.edu / password123');
  } catch (error) {
    console.error('Seeding failed:', error.message);
    process.exit(1);
  } finally {
    await mongoose.connection.close();
    process.exit(0);
  }
};

seed();
