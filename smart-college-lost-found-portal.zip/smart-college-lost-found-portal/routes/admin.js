const fs = require('fs');
const path = require('path');
const express = require('express');
const Item = require('../models/Item');
const { verifyToken, requireAdmin } = require('../middleware/auth');

const router = express.Router();

const ITEM_STATUSES = ['pending', 'claimed', 'resolved'];

const STATUS_TRANSITIONS = {
  pending: ['claimed'],
  claimed: ['resolved'],
  resolved: [],
};

const getUserId = (req) => req.user._id || req.user.id;

router.use(verifyToken, requireAdmin);

router.get('/items', async (_req, res) => {
  try {
    const items = await Item.find()
      .sort({ createdAt: -1 })
      .populate('reportedBy', 'name email role')
      .populate('verifiedBy', 'name email role');

    res.json({ count: items.length, items });
  } catch (error) {
    res.status(500).json({ message: error.message || 'Failed to fetch items' });
  }
});

router.patch('/items/:id/status', async (req, res) => {
  try {
    const { status } = req.body;

    if (!status || !ITEM_STATUSES.includes(status)) {
      return res.status(400).json({ message: 'Valid status is required (pending, claimed, resolved)' });
    }

    const item = await Item.findById(req.params.id);
    if (!item) {
      return res.status(404).json({ message: 'Item not found' });
    }

    const allowedNext = STATUS_TRANSITIONS[item.status] || [];
    if (!allowedNext.includes(status)) {
      return res.status(400).json({
        message: `Invalid status transition from '${item.status}' to '${status}'`,
      });
    }

    item.status = status;
    item.verifiedBy = getUserId(req);
    await item.save();

    await item.populate([
      { path: 'reportedBy', select: 'name email role' },
      { path: 'verifiedBy', select: 'name email role' },
    ]);

    res.json({ message: 'Item status updated', item });
  } catch (error) {
    if (error.name === 'CastError') {
      return res.status(400).json({ message: 'Invalid item id' });
    }
    res.status(500).json({ message: error.message || 'Failed to update item status' });
  }
});

const unlinkItemImage = (imageUrl) => {
  if (!imageUrl?.startsWith('/uploads/')) {
    return;
  }

  const filePath = path.join(__dirname, '..', 'public', imageUrl);
  if (fs.existsSync(filePath)) {
    fs.unlinkSync(filePath);
  }
};

router.delete('/items/:id', async (req, res) => {
  try {
    const item = await Item.findById(req.params.id);
    if (!item) {
      return res.status(404).json({ message: 'Item not found' });
    }

    unlinkItemImage(item.imageUrl);
    await Item.findByIdAndDelete(req.params.id);

    res.json({ message: 'Item deleted successfully' });
  } catch (error) {
    if (error.name === 'CastError') {
      return res.status(400).json({ message: 'Invalid item id' });
    }
    res.status(500).json({ message: error.message || 'Failed to delete item' });
  }
});

module.exports = router;
