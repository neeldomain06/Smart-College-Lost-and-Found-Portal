const express = require('express');
const Item = require('../models/Item');
const { verifyToken } = require('../middleware/auth');
const upload = require('../utils/upload');

const router = express.Router();

const ITEM_CATEGORIES = ['electronics', 'documents', 'keys', 'clothing', 'other'];
const ITEM_TYPES = ['lost', 'found'];
const ITEM_STATUSES = ['pending', 'claimed', 'resolved'];

const getUserId = (req) => req.user._id || req.user.id;

router.post('/', verifyToken, upload.single('image'), async (req, res) => {
  try {
    const { title, description, category, type, location, date } = req.body;

    if (!title?.trim() || !description?.trim() || !category || !type || !location?.trim() || !date) {
      return res.status(400).json({
        message: 'title, description, category, type, location, and date are required',
      });
    }

    if (!ITEM_CATEGORIES.includes(category)) {
      return res.status(400).json({ message: 'Invalid category' });
    }

    if (!ITEM_TYPES.includes(type)) {
      return res.status(400).json({ message: 'Invalid type' });
    }

    const imageUrl = req.file ? `/uploads/${req.file.filename}` : '';

    const item = await Item.create({
      title: title.trim(),
      description: description.trim(),
      category,
      type,
      location: location.trim(),
      date: new Date(date),
      imageUrl,
      reportedBy: getUserId(req),
    });

    res.status(201).json({ message: 'Item reported successfully', item });
  } catch (error) {
    res.status(500).json({ message: error.message || 'Failed to create item' });
  }
});

router.get('/my-items', verifyToken, async (req, res) => {
  try {
    const items = await Item.find({ reportedBy: getUserId(req) })
      .sort({ createdAt: -1 })
      .populate('reportedBy', 'name email role')
      .populate('verifiedBy', 'name email role');

    res.json({ count: items.length, items });
  } catch (error) {
    res.status(500).json({ message: error.message || 'Failed to fetch your items' });
  }
});

router.get('/', async (req, res) => {
  try {
    const { category, type, status, search } = req.query;
    const filter = {};

    if (category) {
      if (!ITEM_CATEGORIES.includes(category)) {
        return res.status(400).json({ message: 'Invalid category filter' });
      }
      filter.category = category;
    }

    if (type) {
      if (!ITEM_TYPES.includes(type)) {
        return res.status(400).json({ message: 'Invalid type filter' });
      }
      filter.type = type;
    }

    if (status) {
      if (!ITEM_STATUSES.includes(status)) {
        return res.status(400).json({ message: 'Invalid status filter' });
      }
      filter.status = status;
    }

    if (search?.trim()) {
      const keyword = search.trim();
      filter.$or = [
        { title: { $regex: keyword, $options: 'i' } },
        { description: { $regex: keyword, $options: 'i' } },
        { location: { $regex: keyword, $options: 'i' } },
      ];
    }

    const items = await Item.find(filter)
      .sort({ createdAt: -1 })
      .populate('reportedBy', 'name email role')
      .populate('verifiedBy', 'name email role');

    res.json({ count: items.length, items });
  } catch (error) {
    res.status(500).json({ message: error.message || 'Failed to fetch items' });
  }
});

router.use((error, req, res, next) => {
  if (error?.name === 'MulterError') {
    return res.status(400).json({ message: error.message });
  }

  if (error?.message?.includes('Only image files')) {
    return res.status(400).json({ message: error.message });
  }

  next(error);
});

module.exports = router;
