import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import api, { getErrorMessage, isCanceled } from '../api';
import ItemCard from '../components/ItemCard';
import { CATEGORIES, STATUSES, TYPES } from '../constants';

const ACTIVE_STYLES = {
  type: 'bg-indigo-600 text-white',
  category: 'bg-emerald-600 text-white',
  status: 'bg-amber-600 text-white',
};

function FilterGroup({ label, name, options, value, onChange }) {
  return (
    <div className="mb-4 flex flex-wrap items-center gap-2">
      <span className="text-sm font-semibold text-slate-600">{label}:</span>
      {options.map((option) => {
        const isActive = value === option;
        return (
          <button
            key={option}
            type="button"
            aria-pressed={isActive}
            // Clicking the active pill again clears that filter
            onClick={() => onChange(name, isActive ? '' : option)}
            className={`rounded-full px-3 py-1 text-xs font-medium ${
              isActive ? ACTIVE_STYLES[name] : 'bg-slate-200 text-slate-700 hover:bg-slate-300'
            }`}
          >
            {option}
          </button>
        );
      })}
    </div>
  );
}

// Ignore anything in the URL that the API wouldn't accept.
const pick = (value, allowed) => (allowed.includes(value) ? value : '');

export default function Home() {
  const [searchParams, setSearchParams] = useSearchParams();

  const search = searchParams.get('search')?.trim() || '';
  const type = pick(searchParams.get('type'), TYPES);
  const category = pick(searchParams.get('category'), CATEGORIES);
  const status = pick(searchParams.get('status'), STATUSES);

  const [searchInput, setSearchInput] = useState(search);
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  // Keep the box in sync when filters are cleared / changed via the URL
  useEffect(() => {
    setSearchInput(search);
  }, [search]);

  useEffect(() => {
    const controller = new AbortController();
    const params = {};
    if (search) params.search = search;
    if (type) params.type = type;
    if (category) params.category = category;
    if (status) params.status = status;

    setLoading(true);
    setError('');

    api
      .get('/items', { params, signal: controller.signal })
      .then(({ data }) => setItems(data.items))
      .catch((err) => {
        if (isCanceled(err)) return;
        setItems([]);
        setError(getErrorMessage(err, 'Failed to load items'));
      })
      .finally(() => {
        if (!controller.signal.aborted) setLoading(false);
      });

    return () => controller.abort();
  }, [search, type, category, status]);

  const updateFilters = (changes) => {
    const next = { search, type, category, status, ...changes };
    const params = {};
    Object.entries(next).forEach(([key, value]) => {
      if (value) params[key] = value;
    });
    setSearchParams(params);
  };

  const handleSearch = (event) => {
    event.preventDefault();
    updateFilters({ search: searchInput.trim() });
  };

  return (
    <>
      <section className="mb-8">
        <h1 className="text-3xl font-bold text-slate-900">Campus Lost &amp; Found</h1>
        <p className="mt-2 text-slate-600">
          Browse reports, search listings, and filter by category or status.
        </p>
      </section>

      <form onSubmit={handleSearch} className="mb-6 flex flex-col gap-3 sm:flex-row">
        <input
          type="search"
          value={searchInput}
          onChange={(event) => setSearchInput(event.target.value)}
          placeholder="Search title, description, or location..."
          aria-label="Search items"
          className="flex-1 rounded-lg border border-slate-300 px-4 py-2 focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-200"
        />
        <button
          type="submit"
          className="rounded-lg bg-indigo-600 px-5 py-2 font-medium text-white hover:bg-indigo-700"
        >
          Search
        </button>
        <button
          type="button"
          onClick={() => setSearchParams({})}
          className="rounded-lg border border-slate-300 px-5 py-2 text-center font-medium text-slate-700 hover:bg-slate-100"
        >
          Clear
        </button>
      </form>

      <FilterGroup
        label="Type"
        name="type"
        options={TYPES}
        value={type}
        onChange={(name, value) => updateFilters({ [name]: value })}
      />
      <FilterGroup
        label="Category"
        name="category"
        options={CATEGORIES}
        value={category}
        onChange={(name, value) => updateFilters({ [name]: value })}
      />
      <div className="mb-4" />
      <FilterGroup
        label="Status"
        name="status"
        options={STATUSES}
        value={status}
        onChange={(name, value) => updateFilters({ [name]: value })}
      />

      {error && (
        <p role="alert" className="mb-4 mt-4 rounded-lg bg-red-50 px-4 py-3 text-red-700">
          {error}
        </p>
      )}

      {loading ? (
        <p className="mt-8 text-center text-slate-500">Loading items...</p>
      ) : items.length === 0 ? (
        !error && (
          <div className="mt-4 rounded-xl border border-dashed border-slate-300 bg-white p-10 text-center text-slate-500">
            No items match your filters.
          </div>
        )
      ) : (
        <div className="mt-4 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {items.map((item) => (
            <ItemCard key={item._id} item={item} />
          ))}
        </div>
      )}
    </>
  );
}
