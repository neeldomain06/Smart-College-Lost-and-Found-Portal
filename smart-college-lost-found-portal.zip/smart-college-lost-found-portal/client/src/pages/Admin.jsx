import { useEffect, useState } from 'react';
import api, { getErrorMessage, isCanceled } from '../api';
import StatusBadge from '../components/StatusBadge';

// The API only allows pending -> claimed -> resolved (see routes/admin.js).
const NEXT_STATUS = {
  pending: { status: 'claimed', label: 'Mark claimed', className: 'bg-indigo-600 hover:bg-indigo-700' },
  claimed: { status: 'resolved', label: 'Mark resolved', className: 'bg-emerald-600 hover:bg-emerald-700' },
};

export default function Admin() {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState('');
  const [message, setMessage] = useState(null); // { text, isError }
  const [busyId, setBusyId] = useState(null);

  useEffect(() => {
    const controller = new AbortController();

    api
      .get('/admin/items', { signal: controller.signal })
      .then(({ data }) => setItems(data.items))
      .catch((err) => {
        if (!isCanceled(err)) setLoadError(getErrorMessage(err, 'Failed to load items'));
      })
      .finally(() => {
        if (!controller.signal.aborted) setLoading(false);
      });

    return () => controller.abort();
  }, []);

  const advanceStatus = async (item, nextStatus) => {
    setBusyId(item._id);
    setMessage(null);

    try {
      const { data } = await api.patch(`/admin/items/${item._id}/status`, { status: nextStatus });
      setItems((current) => current.map((entry) => (entry._id === item._id ? data.item : entry)));
      setMessage({ text: `"${item.title}" marked as ${nextStatus}.`, isError: false });
    } catch (err) {
      setMessage({ text: getErrorMessage(err, 'Failed to update status'), isError: true });
    } finally {
      setBusyId(null);
    }
  };

  const deleteItem = async (item) => {
    if (!window.confirm(`Delete "${item.title}"?`)) return;

    setBusyId(item._id);
    setMessage(null);

    try {
      await api.delete(`/admin/items/${item._id}`);
      setItems((current) => current.filter((entry) => entry._id !== item._id));
      setMessage({ text: `"${item.title}" deleted.`, isError: false });
    } catch (err) {
      setMessage({ text: getErrorMessage(err, 'Failed to delete item'), isError: true });
    } finally {
      setBusyId(null);
    }
  };

  return (
    <>
      <section className="mb-6">
        <h1 className="text-3xl font-bold text-slate-900">Admin Panel</h1>
        <p className="mt-2 text-slate-600">
          Review all reports, advance statuses, or remove invalid listings.
        </p>
      </section>

      {message && (
        <p
          role={message.isError ? 'alert' : 'status'}
          className={`mb-4 rounded-lg px-4 py-3 text-sm ${
            message.isError ? 'bg-red-50 text-red-700' : 'bg-emerald-50 text-emerald-700'
          }`}
        >
          {message.text}
        </p>
      )}

      {loadError && (
        <p role="alert" className="mb-4 rounded-lg bg-red-50 px-4 py-3 text-red-700">
          {loadError}
        </p>
      )}

      {loading ? (
        <p className="text-center text-slate-500">Loading reports...</p>
      ) : items.length === 0 ? (
        !loadError && (
          <div className="rounded-xl border border-dashed border-slate-300 bg-white p-10 text-center text-slate-500">
            There are no reports yet.
          </div>
        )
      ) : (
        <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white shadow-sm">
          <table className="min-w-full text-left text-sm">
            <thead className="border-b border-slate-200 bg-slate-50 text-slate-600">
              <tr>
                <th className="px-4 py-3">Title</th>
                <th className="px-4 py-3">Reporter</th>
                <th className="px-4 py-3">Type</th>
                <th className="px-4 py-3">Status</th>
                <th className="px-4 py-3">Actions</th>
              </tr>
            </thead>
            <tbody>
              {items.map((item) => {
                const next = NEXT_STATUS[item.status];
                const busy = busyId === item._id;

                return (
                  <tr key={item._id} className="border-b border-slate-100">
                    <td className="px-4 py-3">
                      <p className="font-medium text-slate-900">{item.title}</p>
                      <p className="text-xs text-slate-500">{item.location}</p>
                    </td>
                    <td className="px-4 py-3">{item.reportedBy?.name || 'Unknown'}</td>
                    <td className="px-4 py-3 capitalize">{item.type}</td>
                    <td className="px-4 py-3">
                      <StatusBadge status={item.status} />
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex flex-wrap gap-2">
                        {next && (
                          <button
                            type="button"
                            disabled={busy}
                            onClick={() => advanceStatus(item, next.status)}
                            className={`rounded px-2 py-1 text-xs font-medium text-white disabled:cursor-not-allowed disabled:opacity-60 ${next.className}`}
                          >
                            {next.label}
                          </button>
                        )}
                        <button
                          type="button"
                          disabled={busy}
                          onClick={() => deleteItem(item)}
                          className="rounded bg-red-600 px-2 py-1 text-xs font-medium text-white hover:bg-red-700 disabled:cursor-not-allowed disabled:opacity-60"
                        >
                          Delete
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </>
  );
}
