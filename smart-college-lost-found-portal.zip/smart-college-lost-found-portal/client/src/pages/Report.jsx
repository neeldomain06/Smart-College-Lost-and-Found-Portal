import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import api, { getErrorMessage } from '../api';
import { ALLOWED_IMAGE_TYPES, CATEGORIES, MAX_IMAGE_BYTES, TYPES } from '../constants';

const today = () => new Date().toISOString().slice(0, 10);

export default function Report() {
  const navigate = useNavigate();

  const [form, setForm] = useState({
    title: '',
    description: '',
    type: TYPES[0],
    category: CATEGORIES[0],
    location: '',
    date: today(),
  });
  const [image, setImage] = useState(null);
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const handleChange = (event) => {
    setForm((current) => ({ ...current, [event.target.name]: event.target.value }));
  };

  const handleImageChange = (event) => {
    const file = event.target.files?.[0] || null;
    setError('');

    if (file && !ALLOWED_IMAGE_TYPES.includes(file.type)) {
      setError('Only image files are allowed (jpg, jpeg, png, webp)');
      event.target.value = '';
      setImage(null);
      return;
    }

    if (file && file.size > MAX_IMAGE_BYTES) {
      setError('Image must be 5 MB or smaller');
      event.target.value = '';
      setImage(null);
      return;
    }

    setImage(file);
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    setError('');
    setSubmitting(true);

    // Multipart body so multer on the server can pick up the "image" field.
    const formData = new FormData();
    Object.entries(form).forEach(([key, value]) => formData.append(key, value));
    if (image) {
      formData.append('image', image);
    }

    try {
      await api.post('/items', formData);
      navigate('/dashboard', { state: { flash: 'Report submitted successfully.' } });
    } catch (err) {
      setError(getErrorMessage(err, 'Failed to submit report'));
      setSubmitting(false);
    }
  };

  const inputClass =
    'w-full rounded-lg border border-slate-300 px-3 py-2 focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-200';
  const labelClass = 'mb-1 block text-sm font-medium text-slate-700';

  return (
    <div className="mx-auto max-w-2xl rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
      <h1 className="mb-2 text-2xl font-bold text-slate-900">Report Lost or Found Item</h1>
      <p className="mb-6 text-sm text-slate-600">
        Submit details and optionally upload a photo to help others identify the item.
      </p>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="title" className={labelClass}>
            Title
          </label>
          <input
            id="title"
            name="title"
            required
            value={form.title}
            onChange={handleChange}
            className={inputClass}
          />
        </div>

        <div>
          <label htmlFor="description" className={labelClass}>
            Description
          </label>
          <textarea
            id="description"
            name="description"
            rows={4}
            required
            value={form.description}
            onChange={handleChange}
            className={inputClass}
          />
        </div>

        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <label htmlFor="type" className={labelClass}>
              Type
            </label>
            <select
              id="type"
              name="type"
              required
              value={form.type}
              onChange={handleChange}
              className={inputClass}
            >
              {TYPES.map((type) => (
                <option key={type} value={type}>
                  {type}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label htmlFor="category" className={labelClass}>
              Category
            </label>
            <select
              id="category"
              name="category"
              required
              value={form.category}
              onChange={handleChange}
              className={inputClass}
            >
              {CATEGORIES.map((category) => (
                <option key={category} value={category}>
                  {category}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <label htmlFor="location" className={labelClass}>
              Location
            </label>
            <input
              id="location"
              name="location"
              required
              value={form.location}
              onChange={handleChange}
              className={inputClass}
            />
          </div>
          <div>
            <label htmlFor="date" className={labelClass}>
              Date
            </label>
            <input
              id="date"
              name="date"
              type="date"
              required
              max={today()}
              value={form.date}
              onChange={handleChange}
              className={inputClass}
            />
          </div>
        </div>

        <div>
          <label htmlFor="image" className={labelClass}>
            Image (jpg, png, webp, up to 5 MB)
          </label>
          <input
            id="image"
            name="image"
            type="file"
            accept=".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp"
            onChange={handleImageChange}
            className={inputClass}
          />
        </div>

        {error && (
          <p role="alert" className="rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700">
            {error}
          </p>
        )}

        <button
          type="submit"
          disabled={submitting}
          className="rounded-lg bg-indigo-600 px-5 py-2 font-medium text-white hover:bg-indigo-700 disabled:cursor-not-allowed disabled:opacity-60"
        >
          {submitting ? 'Submitting...' : 'Submit report'}
        </button>
      </form>
    </div>
  );
}
