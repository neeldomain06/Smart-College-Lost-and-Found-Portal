import axios from 'axios';

export const TOKEN_KEY = 'token';
export const USER_KEY = 'user';
export const UNAUTHORIZED_EVENT = 'auth:unauthorized';

// Empty in development (Vite proxies /api and /uploads to Express).
// Set VITE_API_URL when the API lives on another origin.
const API_ORIGIN = (import.meta.env.VITE_API_URL || '').replace(/\/$/, '');

const api = axios.create({ baseURL: `${API_ORIGIN}/api` });

// Attach the JWT to every request. Content-Type is left to axios so that
// FormData uploads get the correct multipart boundary.
api.interceptors.request.use((config) => {
  const token = localStorage.getItem(TOKEN_KEY);
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// If the server rejects our token (expired / invalid), tell AuthContext to log out.
api.interceptors.response.use(
  (response) => response,
  (error) => {
    const url = error.config?.url || '';
    const isAuthForm = url.startsWith('/auth/');
    if (error.response?.status === 401 && !isAuthForm && localStorage.getItem(TOKEN_KEY)) {
      window.dispatchEvent(new Event(UNAUTHORIZED_EVENT));
    }
    return Promise.reject(error);
  }
);

export const isCanceled = axios.isCancel;

export const getErrorMessage = (error, fallback = 'Something went wrong') =>
  error?.response?.data?.message || error?.message || fallback;

// Item images are stored as "/uploads/<file>" by the server.
export const assetUrl = (path) => (path ? `${API_ORIGIN}${path}` : '');

export default api;
