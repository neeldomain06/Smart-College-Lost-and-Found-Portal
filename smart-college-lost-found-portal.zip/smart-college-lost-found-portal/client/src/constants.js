// Keep these in sync with models/Item.js on the server.
export const CATEGORIES = ['electronics', 'documents', 'keys', 'clothing', 'other'];
export const TYPES = ['lost', 'found'];
export const STATUSES = ['pending', 'claimed', 'resolved'];

// Used to restrict image uploads before they reach the server (see utils/upload.js).
export const ALLOWED_IMAGE_TYPES = ['image/jpeg', 'image/png', 'image/webp'];
export const MAX_IMAGE_BYTES = 5 * 1024 * 1024;
