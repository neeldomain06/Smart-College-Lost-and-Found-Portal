import { Link, NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const linkClass = ({ isActive }) =>
  `rounded-lg px-3 py-2 ${
    isActive ? 'bg-indigo-100 text-indigo-800' : 'text-slate-600 hover:bg-slate-100'
  }`;

export default function Navbar() {
  const { user, isAuthenticated, isAdmin, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <header className="border-b border-slate-200 bg-white shadow-sm">
      <nav className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-4 px-4 py-4">
        <Link to="/" className="text-lg font-bold text-indigo-700">
          Smart College Lost &amp; Found
        </Link>

        <div className="flex flex-wrap items-center gap-2 text-sm font-medium">
          <NavLink to="/" end className={linkClass}>
            Feed
          </NavLink>

          {isAuthenticated ? (
            <>
              <NavLink to="/report" className={linkClass}>
                Report
              </NavLink>
              <NavLink to="/dashboard" className={linkClass}>
                Dashboard
              </NavLink>
              {isAdmin && (
                <NavLink to="/admin" className={linkClass}>
                  Admin
                </NavLink>
              )}
              <span className="hidden text-slate-500 sm:inline">Hi, {user?.name}</span>
              <button
                type="button"
                onClick={handleLogout}
                className="rounded-lg bg-slate-800 px-3 py-2 text-white hover:bg-slate-900"
              >
                Logout
              </button>
            </>
          ) : (
            <>
              <NavLink to="/login" className={linkClass}>
                Login
              </NavLink>
              <Link
                to="/register"
                className="rounded-lg bg-indigo-600 px-3 py-2 text-white hover:bg-indigo-700"
              >
                Register
              </Link>
            </>
          )}
        </div>
      </nav>
    </header>
  );
}
