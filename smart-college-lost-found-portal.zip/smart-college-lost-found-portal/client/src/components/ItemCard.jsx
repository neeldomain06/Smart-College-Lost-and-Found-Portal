import { assetUrl } from '../api';
import StatusBadge from './StatusBadge';

export default function ItemCard({ item }) {
  return (
    <article className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">
      {item.imageUrl ? (
        <img src={assetUrl(item.imageUrl)} alt={item.title} className="h-44 w-full object-cover" />
      ) : (
        <div className="flex h-44 items-center justify-center bg-slate-100 text-sm text-slate-400">
          No image
        </div>
      )}

      <div className="space-y-2 p-4">
        <div className="flex flex-wrap gap-2">
          <span className="rounded-full bg-indigo-100 px-2 py-0.5 text-xs font-semibold uppercase text-indigo-800">
            {item.type}
          </span>
          <span className="rounded-full bg-emerald-100 px-2 py-0.5 text-xs font-semibold text-emerald-800">
            {item.category}
          </span>
          <StatusBadge status={item.status} />
        </div>

        <h2 className="text-lg font-semibold text-slate-900">{item.title}</h2>
        <p className="line-clamp-3 text-sm text-slate-600">{item.description}</p>
        <p className="text-xs text-slate-500">Location: {item.location}</p>
        <p className="text-xs text-slate-500">Date: {new Date(item.date).toLocaleDateString()}</p>
        {item.reportedBy?.name && (
          <p className="text-xs text-slate-500">Reported by: {item.reportedBy.name}</p>
        )}
      </div>
    </article>
  );
}
