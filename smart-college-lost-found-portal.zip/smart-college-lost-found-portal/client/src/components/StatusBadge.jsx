const STYLES = {
  pending: 'bg-amber-100 text-amber-800',
  claimed: 'bg-indigo-100 text-indigo-800',
  resolved: 'bg-emerald-100 text-emerald-800',
};

export default function StatusBadge({ status }) {
  return (
    <span
      className={`rounded-full px-2 py-0.5 text-xs font-semibold ${
        STYLES[status] || 'bg-slate-100 text-slate-700'
      }`}
    >
      {status}
    </span>
  );
}
